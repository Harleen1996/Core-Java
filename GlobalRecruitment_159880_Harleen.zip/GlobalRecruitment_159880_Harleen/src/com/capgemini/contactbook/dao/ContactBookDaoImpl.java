package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.util.ConnectionProvider;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	private static Connection conn = ConnectionProvider.getDBConnection();
	private static final Logger logger = Logger.getLogger(ContactBookDao.class);
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException,SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("INSERT INTO ENQUIRY(ENQRYID,FIRSTNAME, LASTNAME,CONTACTNO, DOMAIN,CITY)VALUES(ENQUIRIES.NEXTVAL,?,?,?,?,?)");
			pstmt1.setString(1, enqry.getfName());
			pstmt1.setString(2, enqry.getlName());
			pstmt1.setString(3,enqry.getContactNo());
			pstmt1.setString(4,enqry.getpDomain());
			pstmt1.setString(5,enqry.getpLocation());
			pstmt1.executeQuery();
			conn.commit();
			logger.error("Inserted record into enquiry");
			PreparedStatement pstmt2 = conn.prepareStatement("SELECT MAX(ENQRYID) FROM ENQUIRY");
			ResultSet RS = pstmt2.executeQuery();
			RS.next();
			logger.error("Fetched enquiryId from enquiry");
			int enqryId=RS.getInt(1);
			enqry.setEnqryId(enqryId);
			return enqryId;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
		
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException ,SQLException{
		PreparedStatement pstmt1 = conn.prepareStatement("SELECT * FROM ENQUIRY WHERE ENQRYID="+EnquiryID);
		ResultSet RS = pstmt1.executeQuery();
		if(RS.next()){
			int enqryId = RS.getInt("enqryId");
			String fName = RS.getString("firstName");
			String lName= RS.getString("lastName");
			String contactNo= RS.getString("contactNo");
			String pDomain=RS.getString("domain");
			String pLocation=RS.getString("city");
			logger.error("Fetched enquiry Details from enquiry");
		
			EnquiryBean enquiryBean = new EnquiryBean(enqryId, fName, lName, contactNo, pLocation, pDomain);
		return enquiryBean;
	}
		return null;
	}
}

