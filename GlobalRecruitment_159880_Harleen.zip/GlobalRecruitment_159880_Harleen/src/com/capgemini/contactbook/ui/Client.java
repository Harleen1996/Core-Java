package com.capgemini.contactbook.ui;
import java.util.Scanner;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.EnquiryIdNotFound;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.service.ContactBookService;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {

	public static void main(String[] args) {
	ContactBookService contactbookService=new ContactBookServiceImpl();
	
	String wantToContinue = "y";
	int userChoice = 0;
	Scanner sc = new Scanner(System.in);
	while (wantToContinue.equalsIgnoreCase("y")){
		
		System.out.println("Global Recruitments\nChoose an operation\n1. Enter Enquiry Details\n2. View Enquiry Details on Id\n0.Exit\nPlease enter a choice:");
		userChoice = sc.nextInt();
		switch (userChoice) {
		case 1:
			try{
				
			System.out.println("Enter First Name: ");
			String fName = sc.next();
			sc.nextLine();
			
			System.out.println("Enter Last Name: ");
			String lName = sc.next();
			System.out.println("Enter Contact Number: ");
			String contactNo = sc.next();
			System.out.println("Enter Preferred domain: ");
			String pDomain = sc.next();
			System.out.println("Enter Preferred Location: ");
			String pLocation = sc.next();
				System.out.println("Enter customer phone number: ");
	
			EnquiryBean enqry=new EnquiryBean(fName, lName, contactNo, pLocation, pDomain);
			int enqryId=contactbookService.addEnquiry(enqry);
			System.out.println("Thank you "+fName+" "+lName+" your Unique Id is "+enqryId +" We will contact you shortly");
			}catch (ContactBookException e) { System.err.println(e.getMessage()); }
			break;
			
		case 2:
			try{
				System.out.println("Enter the enquiry No.: ");
			int enqryId1= sc.nextInt();
			System.out.println(contactbookService.getEnquiryDetails(enqryId1));
			}catch(EnquiryIdNotFound | ContactBookException e){System.err.println(e.getMessage()); }
		    break;
		
		case 0:
			System.out.println("Thank you for selecting us!!");
			System.exit(0);
			break;
			
			default:
				System.out.println("Enter valid choice");
				break;
		}
		
		System.out.println("\nDo you wanna continue(y/n):");
		wantToContinue = sc.next();
		sc.nextLine();
	}
	sc.close();
	
}
}
