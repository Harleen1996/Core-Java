package com.capgemini.contactbook.exceptions;

public class EnquiryIdNotFound extends Exception {

	public EnquiryIdNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EnquiryIdNotFound(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EnquiryIdNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EnquiryIdNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EnquiryIdNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
