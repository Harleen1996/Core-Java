package com.capgemini.contactbook.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.EnquiryIdNotFound;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService  {

	ContactBookDao contactBookDao=new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
	try {
		
		isValidEnquiry(enqry);
		int enqryId=contactBookDao.addEnquiry(enqry);
				return enqryId;
	} catch (SQLException e) {
		e.printStackTrace();
		throw new ContactBookException("Server Down");
	}
}


	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException,EnquiryIdNotFound {
		try {
			EnquiryBean enquiryBean= contactBookDao.getEnquiryDetails(EnquiryID);
			if ( enquiryBean== null) throw new EnquiryIdNotFound("Sorry no details found");
			return enquiryBean;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ContactBookException("Server Down", e);
	}
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		if(!validateContactNo(enqry.getContactNo()))
			throw new ContactBookException("Invalid contact No.!");
	if(!validateFirstName(enqry.getfName()))
	throw new ContactBookException("Invalid First Name!");
	if(!validateLastName(enqry.getlName()))
	throw new ContactBookException("Invalid Last Name!");
	if(!validatePDomain(enqry.getpDomain()))
	throw new ContactBookException("Invalid Domain!");
	else 
		return true;
}
	 public boolean validateContactNo(String contactNo) {
		 if(contactNo.length()!=10)
				return false;
			else
				return true;
			}
		
		public boolean validateFirstName(String fName) {
			Pattern p = Pattern.compile("[A-Za-z\\s]{1,}");
			Matcher m = p.matcher(fName);
			if (m.matches())	return true;
			return false;}
		
		public boolean validateLastName(String lName) {
			Pattern p = Pattern.compile("[A-Za-z\\s]{1,}");
			Matcher m = p.matcher(lName);
			if (m.matches())	return true;
			return false;}
		
		public boolean validatePDomain(String pDomain) {
			Pattern p = Pattern.compile("[A-Za-z\\s]{1,}");
			Matcher m = p.matcher(pDomain);
			if (m.matches())	return true;
			return false;}
	}