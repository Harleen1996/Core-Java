package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoTest {
	private static ContactBookServiceImpl contactBookServiceImpl;
	@BeforeClass
	public static void setupUpTestClass(){ contactBookServiceImpl = new ContactBookServiceImpl(); }
	@Before
	public void setUpMockDataForTest(){ System.out.println("Setting Up Mock Data For Test"); }
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@After
	public void tearDownMockDataForTest(){ System.out.println("Destroying Mock Data For Test"); }
	@AfterClass
	public static void tearDownTestClass(){ contactBookServiceImpl = null; }
	

}
