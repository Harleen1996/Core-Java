package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.util.ConnectionProvider;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	private static Connection conn = ConnectionProvider.getDBConnection();
	private static final Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into enquiry(enqryId,firstName,lastName,contactNo,domain,city) values(enquiries.nextval,?,?,?,?,?)");
			pstmt1.setString(1, enqry.getfName());
			pstmt1.setString(2, enqry.getlName());
			pstmt1.setLong(3, Long.parseLong(enqry.getContactNo()));
			pstmt1.setString(4, enqry.getpDomain());
			pstmt1.setString(5, enqry.getpLocation());
			pstmt1.executeUpdate();
			conn.commit();
			logger.error("Inserted record into enquiry");
			PreparedStatement pstmt2 = conn.prepareStatement("select max(enqryid)from enquiry");
			ResultSet enquiryIdRS = pstmt2.executeQuery();
			enquiryIdRS.next();
			logger.error("Fetched enquiryId from enquiry");
			return enquiryIdRS.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		try {
			PreparedStatement pstmt1 = conn.prepareStatement("select * from enquiry where enqryId=?");
			pstmt1.setInt(1, EnquiryID);
			ResultSet enquiryRS = pstmt1.executeQuery();
			logger.error("Fetched record from enquiry");
			if(enquiryRS.next()){
				String fName=enquiryRS.getString("firstName");
				String lName=enquiryRS.getString("lastName");
				String contactNo=enquiryRS.getString("contactNo");
				String pLocation=enquiryRS.getString("city");
				String pDomain=enquiryRS.getString("domain");
				EnquiryBean enquiryBean = new EnquiryBean(EnquiryID, fName, lName, contactNo, pLocation, pDomain);
				return enquiryBean;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
		return null;
	}

}
