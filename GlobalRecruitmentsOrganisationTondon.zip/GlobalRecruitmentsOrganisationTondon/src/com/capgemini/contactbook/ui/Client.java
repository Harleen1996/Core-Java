package com.capgemini.contactbook.ui;

import java.util.Scanner;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {

	public static void main(String[] args) {
		try {
			int ch=3;
			Scanner sc = new Scanner(System.in);
			ContactBookService contactBookService= new ContactBookServiceImpl();
			System.out.println("********************Global Recruitments*********************");
			while(ch!=0){
				System.out.println("1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit");
				System.out.println("***********************************************************");
				System.out.println("\nPlease enter a choice: ");
				
				ch = sc.nextInt();
				if(ch!=0){
					switch (ch) {
					case 1:
						System.out.println("Enter First Name : ");
						String fName = sc.next();
						System.out.println("Enter Last Name : ");
						String lName = sc.next();
						String contactNo="";
						System.out.println("Enter Contact Number: ");
						contactNo = sc.next();

						System.out.println("Enter Preferred Domain : ");
						String pDomain = sc.next();
						System.out.println("Enter Preferred Location : ");
						String pLocation = sc.next();
						/*Scanner sc2 = new Scanner(System.in);
						String dd_description = sc2.nextLine();*/
						EnquiryBean enquiryBean = new EnquiryBean(fName, lName, contactNo, pLocation, pDomain);
						int uniqueId=contactBookService.addEnquiry(enquiryBean);
						System.out.println("**********************************************************");
						System.out.println("Thank you "+fName+" "+lName+"your Unique Id is "+uniqueId+" we will contact you shortly.");
						System.out.println("**********************************************************");
						break;
					case 2:
						System.out.println("Enter the Enquiry No.: ");
						int EnquiryID=sc.nextInt();
						EnquiryBean enquiryBean2= contactBookService.getEnquiryDetails(EnquiryID);
						System.out.println("Id\tFirst Name\tLast Name\tContact No.\t Preferred Domain\t Preferred Location");
						System.out.println(enquiryBean2.getEnqryId()+"\t"+enquiryBean2.getfName()+"\t"+enquiryBean2.getlName()+"\t"+enquiryBean2.getContactNo()+"\t"+enquiryBean2.getpDomain()+"\t"+enquiryBean2.getpLocation());
						break;
					default:
						break;
					}
					//sc.close();
				}
			}
			if(ch==0)
				System.out.println("Thank you for selecting us!!");
			sc.close();
		} catch (ContactBookException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}

	}

}
