package com.capgemini.contactbook.service;

import java.sql.SQLException;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {
ContactBookDao contactBookDao = new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		try {
			if(isValidEnquiry(enqry));
			int id=contactBookDao.addEnquiry(enqry);
			return id;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ContactBookException("Service Down!");
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		EnquiryBean enquiryBean = contactBookDao.getEnquiryDetails(EnquiryID);
		if(enquiryBean==null){
			throw new ContactBookException("Sorry no details found.");
		}
		return enquiryBean;
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		if(!validateContactNo(enqry.getContactNo()))
				throw new ContactBookException("Invalid contact No.!");
		if(!validateFirstName(enqry.getfName()))
		throw new ContactBookException("Invalid First Name!");
		if(!validateLastName(enqry.getlName()))
		throw new ContactBookException("Invalid Last Name!");
		if(!validatePDomain(enqry.getpDomain()))
		throw new ContactBookException("Invalid Domain!");
		else 
			return true;
	}
	public boolean validateContactNo(String contactNo){
		if(contactNo.length()!=10)
			return false;
		else
			return true;
		}
	public boolean validateFirstName(String fName){
		if(fName.isEmpty())
			return false;
		else 
			return true;}
	public boolean validateLastName(String lName){
		if(lName.isEmpty())
			return false;
		else 
			return true;}
	public boolean validatePLocation(String pLocation){
		if(pLocation.isEmpty())
			return false;
		else 
			return true;}
	public boolean validatePDomain(String pDomain){
		if(pDomain.isEmpty())
			return false;
		else 
			return true;}
}
