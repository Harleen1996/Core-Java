package com.cg.project.enumdemo;

public class MainClass {
	
	public static void main(String[] args){
		Month month = Month.JAN;
		System.out.println(month.getMonthName());
		System.out.println(month.getMonthIndex());
	}
	
	
}
