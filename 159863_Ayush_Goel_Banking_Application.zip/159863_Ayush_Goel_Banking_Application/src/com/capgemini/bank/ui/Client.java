package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.InvalidDemandDetailsException;
import com.capgemini.bank.exceptions.TransactionRecordNotFoundException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	private static IDemandDraftService demandDraftService = new DemandDraftService();
	public static void main(String[] args) {
		
			String wantToContinue = "y";
			int userChoice = 0;
			Scanner sc = new Scanner(System.in);
			while (wantToContinue.equalsIgnoreCase("y")){
				try{
				System.out.println("XYZ Banking Application\n\n1) Enter Demand Draft Details\n2) Exit\nEnter your choice:");
				userChoice = sc.nextInt();
				switch (userChoice) {
				case 1:
					sc.nextLine();
					System.out.print("Enter the name of the customer : ");
					String customerName = sc.nextLine();
					System.out.print("Enter customer phone number : ");
					String customerContactNumber = sc.nextLine();
					System.out.print("In favour of : ");
					String demandDraftInFavourOf = sc.nextLine();
					System.out.print("Enter the Demand Draft  amount (in Rs.) : ");
					float demandDraftAmount = sc.nextFloat();
					sc.nextLine();
					System.out.print("Enter Remarks: ");
					String customerRemarks = sc.nextLine();
					DemandDraft demandDraft = new DemandDraft(customerName, demandDraftInFavourOf, customerRemarks, customerContactNumber, demandDraftAmount);
					int transactionId = demandDraftService.addDemandDraftDetails(demandDraft);
					System.out.println("Your Demand Draft request has been successfuly registered along with the " + transactionId);
					
					System.out.println("Printing the details of the transaction");
					System.out.println(demandDraftService.getDemandDraftDetails(transactionId).toString());
					break;
					
				case 2:
					System.exit(0);
					break;

				default:
					System.out.println("Enter a valid choice!");
					break;
				}
			}catch (InvalidDemandDetailsException e) { System.err.println(e.getMessage()); }
			catch (BankingServicesDownException e) { System.err.println(e.getMessage()); }
			catch (TransactionRecordNotFoundException e) { System.err.println(e.getMessage()); }
			System.out.println("\nDo you wanna continue(y/n):");
			wantToContinue = sc.next();
			System.out.println();
		}
		sc.close();
		
	}
}
