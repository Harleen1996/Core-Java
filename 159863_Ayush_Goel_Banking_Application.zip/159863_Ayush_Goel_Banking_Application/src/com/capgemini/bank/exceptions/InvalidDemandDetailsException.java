package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class InvalidDemandDetailsException extends Exception{
	public InvalidDemandDetailsException() { super(); }
	public InvalidDemandDetailsException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) { super(message, cause, enableSuppression, writableStackTrace); }
	public InvalidDemandDetailsException(String message, Throwable cause) { super(message, cause); }
	public InvalidDemandDetailsException(String message) { super(message); }
	public InvalidDemandDetailsException(Throwable cause) { super(cause); }
}
