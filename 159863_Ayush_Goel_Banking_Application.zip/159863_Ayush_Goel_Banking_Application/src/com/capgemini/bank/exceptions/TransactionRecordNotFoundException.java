package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class TransactionRecordNotFoundException extends Exception{
	public TransactionRecordNotFoundException() { super(); }
	public TransactionRecordNotFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) { super(message, cause, enableSuppression, writableStackTrace); }
	public TransactionRecordNotFoundException(String message, Throwable cause) { super(message, cause); }
	public TransactionRecordNotFoundException(String message) { super(message); }
	public TransactionRecordNotFoundException(Throwable cause) { super(cause); }
}
