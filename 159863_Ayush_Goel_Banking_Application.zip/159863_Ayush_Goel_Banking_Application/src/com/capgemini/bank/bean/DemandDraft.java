package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {
	int transactionId;
	String customerName, demandDraftInFavourOf, customerRemarks, customerContactNumber;
	float demandDraftAmount, commission;
	Date dateOfTransaction;
	public DemandDraft() { super(); }
	public DemandDraft(int transactionId, String customerName, String demandDraftInFavourOf, String customerRemarks, String customerContactNumber, float demandDraftAmount, float commission, Date dateOfTransaction) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.demandDraftInFavourOf = demandDraftInFavourOf;
		this.customerRemarks = customerRemarks;
		this.customerContactNumber = customerContactNumber;
		this.demandDraftAmount = demandDraftAmount;
		this.commission = commission;
		this.dateOfTransaction = dateOfTransaction;
	}
	public DemandDraft(int transactionId, String customerName, String demandDraftInFavourOf, String customerRemarks, String customerContactNumber, float demandDraftAmount, float commission) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.demandDraftInFavourOf = demandDraftInFavourOf;
		this.customerRemarks = customerRemarks;
		this.customerContactNumber = customerContactNumber;
		this.demandDraftAmount = demandDraftAmount;
		this.commission = commission;
	}
	public DemandDraft(String customerName, String demandDraftInFavourOf, String customerRemarks, String customerContactNumber, float demandDraftAmount) {
		super();
		this.customerName = customerName;
		this.demandDraftInFavourOf = demandDraftInFavourOf;
		this.customerRemarks = customerRemarks;
		this.customerContactNumber = customerContactNumber;
		this.demandDraftAmount = demandDraftAmount;
	}
	public int getTransactionId() { return transactionId; }
	public void setTransactionId(int transactionId) { this.transactionId = transactionId; }
	public String getCustomerName() { return customerName; }
	public void setCustomerName(String customerName) { this.customerName = customerName; }
	public String getDemandDraftInFavourOf() { return demandDraftInFavourOf; }
	public void setDemandDraftInFavourOf(String demandDraftInFavourOf) { this.demandDraftInFavourOf = demandDraftInFavourOf; }
	public String getCustomerRemarks() { return customerRemarks; }
	public void setCustomerRemarks(String customerRemarks) { this.customerRemarks = customerRemarks; }
	public String getCustomerContactNumber() { return customerContactNumber; }
	public void setCustomerContactNumber(String customerContactNumber) { this.customerContactNumber = customerContactNumber; }
	public float getDemandDraftAmount() { return demandDraftAmount; }
	public void setDemandDraftAmount(float demandDraftAmount) { this.demandDraftAmount = demandDraftAmount; }
	public float getCommission() { return commission; }
	public void setCommission(float commission) { this.commission = commission; }
	public Date getDateOfTransaction() { return dateOfTransaction; }
	public void setDateOfTransaction(Date dateOfTransaction) { this.dateOfTransaction = dateOfTransaction; }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(commission);
		result = prime
				* result
				+ ((customerContactNumber == null) ? 0 : customerContactNumber
						.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result
				+ ((customerRemarks == null) ? 0 : customerRemarks.hashCode());
		result = prime
				* result
				+ ((dateOfTransaction == null) ? 0 : dateOfTransaction
						.hashCode());
		result = prime * result + Float.floatToIntBits(demandDraftAmount);
		result = prime
				* result
				+ ((demandDraftInFavourOf == null) ? 0 : demandDraftInFavourOf
						.hashCode());
		result = prime * result + transactionId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DemandDraft other = (DemandDraft) obj;
		if (Float.floatToIntBits(commission) != Float
				.floatToIntBits(other.commission))
			return false;
		if (customerContactNumber == null) {
			if (other.customerContactNumber != null)
				return false;
		} else if (!customerContactNumber.equals(other.customerContactNumber))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (customerRemarks == null) {
			if (other.customerRemarks != null)
				return false;
		} else if (!customerRemarks.equals(other.customerRemarks))
			return false;
		if (dateOfTransaction == null) {
			if (other.dateOfTransaction != null)
				return false;
		} else if (!dateOfTransaction.equals(other.dateOfTransaction))
			return false;
		if (Float.floatToIntBits(demandDraftAmount) != Float
				.floatToIntBits(other.demandDraftAmount))
			return false;
		if (demandDraftInFavourOf == null) {
			if (other.demandDraftInFavourOf != null)
				return false;
		} else if (!demandDraftInFavourOf.equals(other.demandDraftInFavourOf))
			return false;
		if (transactionId != other.transactionId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId
				+ ", customerName=" + customerName + ", demandDraftInFavourOf="
				+ demandDraftInFavourOf + ", customerRemarks="
				+ customerRemarks + ", customerContactNumber="
				+ customerContactNumber + ", demandDraftAmount="
				+ demandDraftAmount + ", commission=" + commission
				+ ", dateOfTransaction=" + dateOfTransaction + "]";
	}
}
