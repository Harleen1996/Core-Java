package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.InvalidDemandDetailsException;
import com.capgemini.bank.exceptions.TransactionRecordNotFoundException;

public class DemandDraftService implements IDemandDraftService{
	private IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) 
			throws InvalidDemandDetailsException, BankingServicesDownException {
		try {
			if (demandDraft.getCustomerName().isEmpty())	throw new InvalidDemandDetailsException("Please enter an appropriate name.");
			else if (demandDraft.getCustomerContactNumber().length() != 10)	throw new InvalidDemandDetailsException("Please enter a valid phone number.");
			else if (demandDraft.getDemandDraftInFavourOf().isEmpty()) throw new InvalidDemandDetailsException("Please fill the In Favour Of field.");
			else if (demandDraft.getDemandDraftAmount() <= 0)	throw new InvalidDemandDetailsException("Enter a valid amount");
			else if (demandDraft.getCustomerRemarks().isEmpty())	throw new InvalidDemandDetailsException("Mention a remark.");
			demandDraft.setCommission(calculateDDCommission(demandDraft.getDemandDraftAmount()));
			int transactionId = demandDraftDAO.addDemandDraftDetails(demandDraft);
			if (transactionId == -1)	throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
			return transactionId;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) 
			throws TransactionRecordNotFoundException, BankingServicesDownException {
		try{
			DemandDraft demandDraft = demandDraftDAO.getDemandDraftDetails(transactionId);
			if (demandDraft == null)	throw new TransactionRecordNotFoundException("Transaction record not found. Please enter a valid transaction id.");
			return demandDraft;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
		}
	}
	
	private float calculateDDCommission(float demandDraftAmount){
		if (demandDraftAmount <= 5000)	return 10;
		else if (demandDraftAmount > 5000 && demandDraftAmount <= 10000)	return 41;
		else if (demandDraftAmount >10000 && demandDraftAmount <=100000)	return 51;
		else	return 306;
	}
}
