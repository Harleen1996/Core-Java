package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.InvalidDemandDetailsException;
import com.capgemini.bank.exceptions.TransactionRecordNotFoundException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) 
			throws InvalidDemandDetailsException, BankingServicesDownException;
	DemandDraft getDemandDraftDetails(int transactionId) 
			throws TransactionRecordNotFoundException, BankingServicesDownException;
}
