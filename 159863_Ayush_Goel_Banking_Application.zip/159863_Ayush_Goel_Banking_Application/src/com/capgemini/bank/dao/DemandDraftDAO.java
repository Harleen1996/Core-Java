package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;
import org.apache.log4j.Logger;

public class DemandDraftDAO implements IDemandDraftDAO {
	private static Connection conn = ConnectionProvider.getDBConnection();
	static Logger log = Logger.getLogger(DemandDraftDAO.class.getName());
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		try {
			conn.setAutoCommit(false);
			String sql = "INSERT INTO DEMAND_DRAFT (TRANSACTION_ID, CUSTOMER_NAME, IN_FAVOR_OF, PHONE_NUMBER, DATE_OF_TRANSACTION, DD_AMOUNT, DD_COMMISSION, DD_DESCRIPTION)  VALUES (TRANSACTION_ID_SEQ.NEXTVAL, ?,  ?,  ?, SYSDATE, ?, ?, ?)";
			PreparedStatement pstmt1 = conn.prepareStatement(sql); 
			pstmt1.setString(1, demandDraft.getCustomerName());
			pstmt1.setString(2, demandDraft.getDemandDraftInFavourOf());
			pstmt1.setString(3, demandDraft.getCustomerContactNumber());
			pstmt1.setFloat(4, demandDraft.getDemandDraftAmount());
			pstmt1.setFloat(5, demandDraft.getCommission());
			pstmt1.setString(6, demandDraft.getCustomerRemarks());
			pstmt1.executeUpdate();

			int transactionId = 0;
			sql = "SELECT MAX(TRANSACTION_ID) FROM DEMAND_DRAFT";
			pstmt1 = conn.prepareStatement(sql);
			ResultSet fetchTransactionId = pstmt1.executeQuery();
			if (fetchTransactionId .next())	transactionId = fetchTransactionId.getInt(1); 
			else	return -1;

			log.info("The Demand Details added with id="+ transactionId);
			conn.commit();
			return transactionId;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		} finally { conn.setAutoCommit(true); }
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		String sql = "SELECT * FROM DEMAND_DRAFT WHERE TRANSACTION_ID=" + transactionId;
		PreparedStatement pstmt1 = conn.prepareStatement(sql);
		ResultSet fetchTransactionDetails = pstmt1.executeQuery();
		if (fetchTransactionDetails.next())
			return new DemandDraft(transactionId, fetchTransactionDetails.getString("CUSTOMER_NAME"), fetchTransactionDetails.getString("IN_FAVOR_OF"), fetchTransactionDetails.getString("DD_DESCRIPTION"), fetchTransactionDetails.getString("PHONE_NUMBER"), fetchTransactionDetails.getFloat("DD_AMOUNT"), fetchTransactionDetails.getFloat("DD_COMMISSION"), fetchTransactionDetails.getDate("DATE_OF_TRANSACTION"));
		return null;
	}
}
