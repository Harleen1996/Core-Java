package com.capgemini.bank.test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
public class DemandDraftServicesTest {
	private static IDemandDraftService demandDraftServices;
	@BeforeClass
	public static void setupUpTestClass(){ demandDraftServices = new DemandDraftService(); }
	@Before
	public void setUpMockDataForTest(){ System.out.println("Setting Up Mock Data For Test"); }
	@After
	public void tearDownMockDataForTest(){ System.out.println("Destroying Mock Data For Test"); }
	@AfterClass
	public static void tearDownTestClass(){ demandDraftServices = null; }
}
