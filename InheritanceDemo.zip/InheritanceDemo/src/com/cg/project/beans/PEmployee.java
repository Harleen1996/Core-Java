package com.cg.project.beans;

public class PEmployee extends Employee {

	private int hr,ta,da;

	public PEmployee() {
		super();
	}

	public PEmployee(int hr, int ta, int da) {
		super();
		this.hr = hr;
		this.ta = ta;
		this.da = da;
	}
	

	public PEmployee(int employeeId, String firstName, String lastName,
			int basicSalary) {
		super(employeeId, firstName, lastName, basicSalary);
	}



	public int getHr() {
		return hr;
	}

	public void setHr(int hr) {
		this.hr = hr;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
	@Override
	public void calculateTotalSalary(){
		hr=(this.getBasicSalary()*10)/100;
		da=(this.getBasicSalary()*10)/100;
		ta=(this.getBasicSalary()*10)/100;
		this.setTotalSalary(this.getBasicSalary()+hr+ta+da);
	}

	@Override
	public String toString() {
		return super.toString()+"hr=" + hr + ", ta=" + ta + ", da=" + da ;
	}
	
		
	}
