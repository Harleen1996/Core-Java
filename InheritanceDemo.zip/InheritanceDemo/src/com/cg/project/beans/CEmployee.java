package com.cg.project.beans;

public final class CEmployee extends Employee {
	private int totalHrs,variablePay;
	public CEmployee() {
		super();
	
	}
	 


	public CEmployee(int employeeId, String firstName, String lastName) {
		super(employeeId, firstName, lastName);
	
	}



	public CEmployee(int totalHrs, int variablePay) {
		super();
		this.totalHrs = totalHrs;
		this.variablePay = variablePay;
	}
 public int getTotalHrs() {
	return totalHrs;
}
 

public void setTotalHrs(int totalHrs) {
	this.totalHrs = totalHrs;
}

public int getVariablePay() {
	return variablePay;
}

public void setVariablePay(int variablePay) {
	this.variablePay = variablePay;
}









@Override
public void calculateTotalSalary() {
	totalHrs=4;
	variablePay=3000;
	this.setTotalSalary (totalHrs*variablePay);
}

@Override
public String toString() {
	return super.toString()+" totalHrs=" + totalHrs + ", variablePay=" + variablePay;
}
 
 public void signContract(){
 }
 }
 

