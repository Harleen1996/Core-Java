package com.cg.project.beans;

public class MainClass {

	public static void main(String[] args) {
		Employee emp;
		
		
		/*Employee employee=new Employee(101,"Harleen","Aggarwal",20000);
		employee.calculateTotalSalary();
 
		System.out.println(emp.toString());
		*/
		/*PEmployee pemp=new PEmployee(102,"Nitika","Garg",20000);*/
	/*	System.out.println(pemp.getEmployeeId());
		System.out.println(employee.getEmployeeId()); 
*/
		/*pemp.calculateTotalSalary();
		System.out.println(pemp.toString());*/
		
		emp=new PEmployee(102,"Nitika","Garg",20000);
		emp.calculateTotalSalary();
		System.out.println(emp);
		
	/*	CEmployee cemp=new CEmployee(103,"Vivek","Singla");
		cemp.calculateTotalSalary();
		System.out.println(cemp.toString());*/
		emp=new CEmployee(103,"Akash","Rao");
		CEmployee cemp=(CEmployee)emp;
		
	
		cemp.signContract();
		emp.calculateTotalSalary();
		System.out.println(emp);
	}

}
