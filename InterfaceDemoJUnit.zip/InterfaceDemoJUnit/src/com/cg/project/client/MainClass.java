 package com.cg.project.client;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservies.MathServices;
import com.cg.project.mathservies.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
	
		/*MathServices mathService= new MathServicesImpl();
		System.out.println(mathService.addNums(3,4));*/
		try{
			MathServices services= new MathServicesImpl();
			services.addNums(10,20);
		}
		catch(InvalidNumberRangeException e){
			e.printStackTrace();
		}
	}
}
