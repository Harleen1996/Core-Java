package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservies.MathServices;
import com.cg.project.mathservies.MathServicesImpl;

public class MathServicesTest {

	private static MathServices mathServices;
	
	@BeforeClass
	public static void setUpTestEnv1(){
		mathServices=new MathServicesImpl();
	}
	
	/*@BeforeClass
	public static void setUpTestEnv2(){
		System.out.println("setUpTestEnv2()");		
	}*/
	
	@Before
	public void setUpMockDataForTest(){
	}
	
    @Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForFirstNoInvalid()throws InvalidNumberRangeException {
    	mathServices.addNums(-100,200);
	}
    
    @Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForSecondNoInvalid()throws InvalidNumberRangeException {
    	mathServices.addNums(100,-200);
	}
    
    @Test
    public void testAddNumbesrForBothValidNo() throws InvalidNumberRangeException {
		int expectedAns=300;
		int actualAns=	mathServices.addNums(100, 200);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
    @After
    public void tearDownMockDataForTest() {
		System.out.println("tearDownMockDataForTest()");
	}
    
    @AfterClass
	public static void tearDownTestEnv() {
		mathServices=null;
	}
}

