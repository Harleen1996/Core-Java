package com.cg.mobile.exceptions;

public class MobileDetailNotFound extends Exception{

	public MobileDetailNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MobileDetailNotFound(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MobileDetailNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MobileDetailNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MobileDetailNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
