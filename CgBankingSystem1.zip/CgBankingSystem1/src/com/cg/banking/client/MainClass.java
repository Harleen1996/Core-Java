package com.cg.banking.client;

public class MainClass {

	public static void main(String[] args) {
		

	}

}
