package com.cg.banking.beans;

public class Address {
	private String city,State,country;
	private int pinCode;
	
	public Address() {
		super();
	}

	public Address(String city, String state, String country, int pinCode) {
		super();
		this.city = city;
		State = state;
		this.country = country;
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	
	
}
