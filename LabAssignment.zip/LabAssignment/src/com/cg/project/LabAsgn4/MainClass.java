package com.cg.project.LabAsgn4;

public class MainClass {
public static void main(String[] args) {
	Account account= new Account(2000, new Person("Smith"));
	Account account1= new Account(3000, new Person("Kathy"));
    account.deposit(2000);
    account1.withdraw(2000);
    System.out.println("Updated Balance in Smith's Account: "+account.getBalance());
	System.out.println("Updated Balance in Kathy's Account: "+account1.getBalance());
	System.out.println(account.toString());
	System.out.println(account1.toString());
}
}
