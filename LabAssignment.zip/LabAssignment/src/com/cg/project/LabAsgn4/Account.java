package com.cg.project.LabAsgn4;

public class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	private static long num=1001;
	
	public void deposit(double amount){
		double newBalance=balance+amount;
		balance=newBalance;
	}
	public void withdraw(double amount){
		double newBalance=balance-amount;
		balance=newBalance;
	}
	
	public Account() {
		super();
	}

	public Account(double balance, Person accHolder) {
		super();
		this.balance = balance;
		this.accHolder = accHolder;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}

	
}