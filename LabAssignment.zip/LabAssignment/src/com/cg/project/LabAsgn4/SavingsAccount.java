package com.cg.project.LabAsgn4;

public class SavingsAccount extends Account{
	private final double minBalance=2500;

	public SavingsAccount() {
		super();
	}

	public SavingsAccount(double balance, Person accHolder) {
		super(balance, accHolder);
	}

	@Override
	public void withdraw(double amount) {
	if((getBalance()-amount)<minBalance){
		System.err.println("Minimum balance should be maintained");
	return;
	}
	setBalance(getBalance()-amount);
	}
}
