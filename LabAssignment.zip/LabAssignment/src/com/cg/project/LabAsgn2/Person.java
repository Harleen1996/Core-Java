package com.cg.project.LabAsgn2;

public class Person{
	private String firstName,lastName;
	private Gender gender;
	private String mobileNo;

public Person() {
		super();
	}

public Person(String firstName, String lastName, Gender gender) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
}

public Person(String firstName, String lastName, Gender gender,String mobileNo) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.mobileNo = mobileNo;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public Gender getGender() {
	return gender;
}

public void setGender(Gender gender) {
	this.gender = gender;
}

public String getMobileNo() {
	return mobileNo;
}

public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

}
