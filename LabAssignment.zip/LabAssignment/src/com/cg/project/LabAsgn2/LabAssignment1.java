package com.cg.project.LabAsgn2;

public class LabAssignment1 {

	public static void main(String[] args) {
	System.out.println("Person Details:");
	System.out.println("____________");
	System.out.println("First Name: Divya");
	System.out.println("Last Name: Bharathi");
	System.out.println("Gender: F");
	System.out.println("Age: 20");
	System.out.println("Weight: 85.55");
	}

}
