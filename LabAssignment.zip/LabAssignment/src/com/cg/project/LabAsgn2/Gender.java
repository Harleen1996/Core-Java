package com.cg.project.LabAsgn2;

	public enum Gender{
	Male('M') ,
	Female('F');
	
	private char Gender;

	public char getGender() {
		return Gender;
	}

	public void setGender(char gender) {
		Gender = gender;
	}

	private Gender(char gender) {
		Gender = gender;
	}
	
}
