package com.cg.project.LabAsgn2;

public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person("Harleen"," Aggarwal", Gender.Male,"9234567890");
		displayPersonDetails(person);
	}
		
		public static void displayPersonDetails(Person person){
		System.out.println("Person Details:");
		System.out.println("____________");
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender:"+person.getGender());
		System.out.println("Mobile No: "+person.getMobileNo());
		}
}



