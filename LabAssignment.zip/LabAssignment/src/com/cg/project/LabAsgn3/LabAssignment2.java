package com.cg.project.LabAsgn3;

public class LabAssignment2 {

	public static void main(String[] args) {
		String str="ANTI";
		int flag=1;
		for(int i=0;i<str.length()-1;i++){
			if(str.charAt(i)>str.charAt(i+1)){
				flag=0;
				break;
			}
		}
			if(flag==1)
				System.out.println("String is Positive");
			else
				System.out.println("String is Negative");
		}
	}


