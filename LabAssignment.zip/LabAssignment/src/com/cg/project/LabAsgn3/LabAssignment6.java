package com.cg.project.LabAsgn3;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class LabAssignment6 {

	public static void main(String[] args) {
 ZonedDateTime currentTime=ZonedDateTime.now();
 ZonedDateTime currentTimeInAmericaNewYork	=ZonedDateTime.now(ZoneId.of("America/New_York"));
 ZonedDateTime currentTimeInEuropeLondon=ZonedDateTime.now(ZoneId.of("Europe/London"));
 ZonedDateTime currentTimeInAsiaTokyo=ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
 ZonedDateTime currentTimeInUSPacific=ZonedDateTime.now(ZoneId.of("US/Pacific"));
 ZonedDateTime currentTimeInAfricaCairo=ZonedDateTime.now(ZoneId.of("Africa/Cairo"));
 ZonedDateTime currentTimeInAustraliaSydney=ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
	
	System.out.println("currentTime: "+currentTime);
	System.out.println("currentTimeInAmerica/NewYork: "+currentTimeInAmericaNewYork);
	System.out.println("currentTimeInEurope/London: "+currentTimeInEuropeLondon);
	System.out.print("currentTimeInAsia/Tokyo: "+currentTimeInAsiaTokyo);
	System.out.println("currentTimeInUS/Pacific: "+currentTimeInUSPacific);
	System.out.println("currentTimeInAfrica/Cairo: "+currentTimeInAfricaCairo);
	System.out.println("currentTimeInAustralia/Sydney: "+currentTimeInAustraliaSydney);
	}
}
