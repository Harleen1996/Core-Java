package com.cg.project.LabAsgn3;

import java.time.LocalDate;
import java.time.Period;

public class LabAssignment4 {

	public static void main(String[] args) {
    LocalDate dateFrom=LocalDate.of(2014,6,14);
    LocalDate dateTo= LocalDate.of(2014,8,20);
    
    Period diff= Period.between(dateFrom, dateTo);
    System.out.println("Difference of days: "+diff.getDays());
    System.out.println("Difference of months: "+diff.getMonths());
    System.out.println("difference of years: "+diff.getYears());
	}

}
