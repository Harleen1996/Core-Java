package com.cg.project.LabAsgn3;

import java.util.Scanner;

public class LabAssignment1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter new String");
		StringBuilder string=new StringBuilder(sc.nextLine());
		String continueOrNo="y";
		while(continueOrNo.equalsIgnoreCase("y")){
			System.out.println("Select operation you want to perform\n1.Add the String to itself\n2.Replace odd positions with #\n3.Remove duplicate characters in the String\n4.Change odd characters to upper case");
		    int choice=sc.nextInt();
		    switch(choice)
		    {
		    case 1:
		    	System.out.println(string.append(string));
		    	break;
		    case 2:
		    	for(int i=0;i<string.length();i+=2)
		    		string.setCharAt(i, '#');
		    	System.out.println(string);
		    case 3:
		    	String result="";
		    	for(int i=0;i<string.length();i++)
		    		if(!result.contains(String.valueOf(string.charAt(i))))
		    			result +=String.valueOf(string.charAt(i));
		    	System.out.println(result);
		    	break;
		    case 4:
		    	String output="";
		    	for(int i=0;i<string.length();i++)
		    		if(i%2!=0)
		    			output +=Character.toUpperCase(string.charAt(i));
		    		else
		    			output +=Character.toLowerCase(string.charAt(i));
		    	System.out.println(output);
		    	break;
		    	default:
		    		System.out.println("Enter valid choice");
		    		break;
		    }
		    System.out.println("Do you want to contine(y/n)");
		    continueOrNo=sc.next();
		}
	}
}

	




