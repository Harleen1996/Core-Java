package com.cg.project.LabAsgn3;

import java.time.LocalDate;

public class LabAssignment3 {

	public static void main(String[] args) {
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate.getDayOfMonth());
		System.out.println(localDate.getMonthValue());
		System.out.println(localDate.getYear());
	}

}
