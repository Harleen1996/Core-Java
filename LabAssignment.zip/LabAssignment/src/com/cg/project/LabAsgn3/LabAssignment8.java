package com.cg.project.LabAsgn3;

public class LabAssignment8 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
