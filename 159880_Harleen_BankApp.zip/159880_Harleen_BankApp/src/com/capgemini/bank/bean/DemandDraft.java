package com.capgemini.bank.bean;

public class DemandDraft {
	private int transactionId,ddAmount,ddCommission;
	private String customerName,inFavorOf,phoneNumber,dateOfTransaction,ddDescription;

	public DemandDraft() {
		super();
	}

	public DemandDraft(int transactionId, int ddAmount, int ddCommission,
			String customerName, String inFavorOf, String phoneNumber,
			String dateOfTransaction, String ddDescription) {
		super();
		this.transactionId = transactionId;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddDescription = ddDescription;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getDdAmount() {
		return ddAmount;
	}

	public void setDdAmount(int ddAmount) {
		this.ddAmount = ddAmount;
	}

	public int getDdCommission() {
		return ddCommission;
	}

	public void setDdCommission(int ddCommission) {
		this.ddCommission = ddCommission;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getInFavorOf() {
		return inFavorOf;
	}

	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public String getDdDescription() {
		return ddDescription;
	}

	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}

	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId + ", ddAmount="
				+ ddAmount + ", ddCommission=" + ddCommission
				+ ", customerName=" + customerName + ", inFavorOf=" + inFavorOf
				+ ", phoneNumber=" + phoneNumber + ", dateOfTransaction="
				+ dateOfTransaction + ", ddDescription=" + ddDescription + "]";
	}


}
