package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	public static void main(String[] args){
		IDemandDraftService demanddraftService=new DemandDraftService();
		String wantToContinue="y";
		Scanner sc=new Scanner(System.in);
		int userChoice=0;
		while(wantToContinue.equalsIgnoreCase("y")){
			System.out.println("Menu");
			System.out.println("1)Enter Demand Draft Details\n2)Exit");
			System.out.println("Enter Choice");
			userChoice=sc.nextInt();
			switch(userChoice) {
			case 1:
				System.out.println("\nEnter the name of the customer:");
				String customerName=sc.next();
				System.out.println("Enter customer phone number:");
				String phoneNumber=sc.next();
				System.out.println("In favor of:");
				String inFavorOf=sc.next();
				System.out.println("Enter Demand Draft Amount(in Rs):");
				int amount=sc.nextInt();
				System.out.println("Enter Remarks:");
				String remarks=sc.next();
				System.out.println("Your Demand Draft request has been successfully registered along with the " + demandDraftServices.addDemandDraftDetails(ddAmount, customerName, inFavorOf, phoneNumber, ddDescription) );
			} catch (BankingServicesDownException e) {
				e.printStackTrace();
			}	
			break;
		case 2:
			System.exit(0);
			break;
		default: 
			System.out.println("Enter valid choice");
			break;
		}
		System.out.println("Do you want to continue(y/n)");
		userChoice=sc.next();
	
	sc.close();
}

}





