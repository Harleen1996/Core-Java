package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DraftDetailsNotFoundException;

public class DemandDraftService implements IDemandDraftService {
	private  IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails( int ddAmount, String customerName,String inFavorOf,String phoneNumber, String ddDescription) 
			throws BankingServicesDownException{
		try {
			DemandDraft demandDraft=new DemandDraft( ddAmount,customerName,inFavorOf,phoneNumber,ddDescription);
			demandDraftDAO.addDemandDraftDetails(demandDraft);
			return demandDraft.getTransactionId();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Services are down.Please try later");
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankingServicesDownException,DraftDetailsNotFoundException{
		try {
			DemandDraft demandDraft= demandDraftDAO.getDemandDraftDetails(transactionId);
			if(demandDraft==null) throw new BankingServicesDownException("Services are down.Please try later");
			return demandDraft;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Services are down.Please try later");
		}}


	@Override
	public int findCommission(int transactionId) throws BankingServicesDownException,DraftDetailsNotFoundException{ 
		try {
			DemandDraft	demandDraft = getDemandDraftDetails(transactionId);
			if(demandDraft.getDdAmount()<=5000)
				return demandDraft.setDdCommission(10);
			else if(demandDraft.getDdAmount()>5000&& demandDraft.getDdAmount()<=10000)
				return demandDraft.setDdCommission(41);
			else if(demandDraft.getDdAmount()>10000&& demandDraft.getDdAmount()<=100000)
				return demandDraft.setDdCommission(51);
			else if(demandDraft.getDdAmount()>100000&& demandDraft.getDdAmount()<=500000)
				return demandDraft.setDdCommission(51);
			return demandDraft.setDdCommission(0);

		} catch (BankingServicesDownException | DraftDetailsNotFoundException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Services are down.Please try later");
		}
	}
}



