package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;


public class DemandDraftDAO implements IDemandDraftDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		try {
			conn.setAutoCommit(false);
		
		PreparedStatement pstmt1=conn.prepareStatement("insert into demand_draft(transaction_id,dd_Amount,dd_Commission,customer_Name,in_Favor_Of,phone_Number, date_Of_Transaction,dd_Description)values(Transaction_Id_Seq.nextval,?,?,?,?,?,?,?)");
		pstmt1.setInt(1, demandDraft.getDdAmount());
		pstmt1.setInt(2, demandDraft.getDdCommission());
		pstmt1.setString(3, demandDraft.getCustomerName());
		pstmt1.setString(4, demandDraft.getInFavorOf());
		pstmt1.setString(5, demandDraft.getPhoneNumber());
		pstmt1.setString(6, demandDraft.getDateOfTransaction());
		pstmt1.setString(7, demandDraft.getDdDescription());
		pstmt1.executeUpdate();
		
		PreparedStatement pstmt2=conn.prepareStatement("select max(transaction_id) from demand_draft");
		ResultSet rs=pstmt2.executeQuery();
		rs.next();
		int transactionId=rs.getInt(1);
		conn.commit();
		demandDraft.setTransactionId(transactionId);
		return demandDraft.getTransactionId();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("Select * from demand_draft where transaction_id="+transactionId);
		ResultSet demandRs=pstmt1.executeQuery();
		if(demandRs.next()){
			String customerName=demandRs.getString("customerName");
			String inFavorOf=demandRs.getString("inFavorOf");
			String phoneNumber=demandRs.getString("phoneNumber");
			String dateOfTransaction=demandRs.getString("dateOfTransaction");
			int ddAmount=demandRs.getInt("ddAmount");
			int ddCommission=demandRs.getInt("ddCommission");
			String ddDescription=demandRs.getString("ddDescription");
			DemandDraft demandDraft=new DemandDraft(transactionId, ddAmount, ddCommission, customerName, inFavorOf, phoneNumber, dateOfTransaction, ddDescription);
		return demandDraft;
	}
		return null;

	}
}



