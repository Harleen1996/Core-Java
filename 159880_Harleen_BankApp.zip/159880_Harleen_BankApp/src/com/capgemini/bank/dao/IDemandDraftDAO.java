package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DraftDetailsNotFoundException;

public interface IDemandDraftService {
	int addDemandDraftDetails(int ddAmount, String customerName,String inFavorOf, String phoneNumber, String ddDescription) throws BankingServicesDownException; 
	DemandDraft getDemandDraftDetails(int transactionId)throws BankingServicesDownException,DraftDetailsNotFoundException;
	int findCommission(int transactionId)throws BankingServicesDownException,DraftDetailsNotFoundException;
	
}