package com.cg.learning.webservice;

import javax.xml.ws.Endpoint;

public class CalculatorPublisher {
	
	public static void main(String[] args){
		//1st argument in the Publisher URI.
		//2nd argument is an SIB instance.
		Endpoint.publish("http://127.0.0.1:9876/cs", new Calculator());//Standard IP address for localhost machines
		System.out.println("Web services has hosted");
	}

}
