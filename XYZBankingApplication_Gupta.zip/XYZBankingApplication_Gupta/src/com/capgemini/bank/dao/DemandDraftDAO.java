package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;

public class DemandDraftDAO implements IDemandDraftDAO {
	private static Connection conn = ConnectionProvider.getDBConnection();
	private static final Logger logger = Logger.getLogger(DemandDraftDAO.class);
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		// TODO Auto-generated method stub
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into demand_draft(transaction_id , dd_amount, dd_commission,customer_name, in_favor_of, phone_number, date_of_transaction, dd_description) values(Transaction_Id_Seq.nextval,?,?,?,?,?,TO_DATE(sysdate,'DD-MM-YYYY'),?)");
			pstmt1.setInt(1, demandDraft.getDd_amount());
			pstmt1.setInt(2, demandDraft.getDd_commission());
			pstmt1.setString(3, demandDraft.getCustomer_name());
			pstmt1.setString(4, demandDraft.getIn_favor_of());
			pstmt1.setString(5, demandDraft.getPhone_number());
			pstmt1.setString(6, demandDraft.getDd_description());
			pstmt1.executeQuery();
			conn.commit();
			logger.error("Inserted record into demand_draft");
			PreparedStatement pstmt2 = conn.prepareStatement("select * from demand_draft where transaction_id in (select max(transaction_id)from demand_draft)");
			ResultSet transactionIdRS = pstmt2.executeQuery();
			transactionIdRS.next();
			logger.error("Fetched transactionId from demand_draft");
			return transactionIdRS.getInt("transaction_id");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
		
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException{
		// TODO Auto-generated method stub
		return null;
	}

}
