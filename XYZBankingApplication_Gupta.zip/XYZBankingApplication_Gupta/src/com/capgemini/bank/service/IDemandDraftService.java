package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) throws BankingServicesDownException;
	DemandDraft getDemandDraftDetails(int transactionId);
}
