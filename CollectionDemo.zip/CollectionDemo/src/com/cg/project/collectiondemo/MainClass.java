package com.cg.project.collectiondemo;

public class MainClass {
	public static void main(String[] args){
		/*ListClassesDemo.arrayListClassWork();
		  ListClassesDemo.LinkedListClassWork();*/
		MapClassDemo.hashMapClassWork();
	}

}
