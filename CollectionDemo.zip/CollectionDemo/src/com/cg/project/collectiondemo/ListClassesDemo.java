package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import com.cg.project.beans.Associate;


public class ListClassesDemo {
		
	public static void arrayListClassWork(){
			
			ArrayList<String> strList = new ArrayList<>();
			
			//insert
			strList.add("Harleen");
			strList.add("Nitika");
			strList.add("Vivek");
			strList.add("Rishabh");
			strList.add("Ayush");
			strList.add("Hitesh");
			
			//searching
			System.out.println(strList.contains("Harleen"));
			System.out.println(strList.indexOf("Harleen"));
			
			//sorting
			Collections.sort(strList);
			
			//iteration
			/*for(int i=0;i<strList.size();i++){
				System.out.println(strList.get(i));
			}*/
			for(String name: strList)
				System.out.println(name);
			
			ArrayList<Associate>associateList=new ArrayList<>();
			
			associateList.add(new Associate(101,15000,"Harleen"));
			associateList.add(new Associate(102,16000,"Nitika"));
			associateList.add(new Associate(103,17000,"Vivek"));
			
			Associate associateToBeSearch = new Associate(102,16000,"Nitika");
			System.out.println(associateList.indexOf(associateToBeSearch));
			System.out.println(associateList.contains(associateToBeSearch));

			Collections.sort(associateList);//comparable
			
			Collections.sort(associateList,new AssociateComparator());//comparator
			
			for(Associate associate:associateList){
				System.out.println(associate);
			}
			
			/*for(Associate associate:associateList){
				if(associate.getAssociateId()==103&&associate.getName().equals("Vivek"));
			}*/
}
		public static void LinkedListClassWork(){
			LinkedList<String>strList=new LinkedList<>();
			
			//insert

			strList.add("Harleen");
			strList.add("Nitika");
			strList.add("Vivek");
			strList.add("Rishabh");
			strList.add("Ayush");
			strList.add("Hitesh");
			
			//searching
			System.out.println(strList.contains("Harleen"));
			System.out.println(strList.indexOf("Harleen"));
			
			//sorting
			Collections.sort(strList);
			
			
			}
			
		}

	


