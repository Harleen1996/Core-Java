package com.cg.project.collectiondemo;

import java.util.HashMap;

import com.cg.project.beans.Associate;

public class MapClassDemo {
	public static void hashMapClassWork(){
	HashMap<Integer,Associate>associates=new HashMap<>();
	
	associates.put(101,new Associate(101,15000,"Harleen"));
	associates.put(103,new Associate(102,16000,"Nitika"));
	associates.put(102,new Associate(103,17000,"Vivek"));
	System.out.println(associates.get(102));
	}
}
	
