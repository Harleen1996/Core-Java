package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.HashSet;

import com.cg.project.beans.Associate;

public class SetClassesdemo {
	public static void hashSetClassWork(){
	HashSet<Associate>associateSet=new HashSet<>();
	
	associateSet.add(new Associate(101,15000,"Harleen"));
	associateSet.add(new Associate(102,16000,"Nitika"));
	associateSet.add(new Associate(103,17000,"Vivek"));
}
}
