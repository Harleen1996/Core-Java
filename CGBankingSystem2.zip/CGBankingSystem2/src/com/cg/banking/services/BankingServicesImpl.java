package com.cg.banking.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO = new AccountDAOImpl();
	

	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, SQLException {
		try {
			Account account = new Account(accountType,initBalance);
			account=accountDAO.save(account);
			return account.getAccountNo();
		} catch (Exception e) {	
			e.printStackTrace();
			throw new BankingServicesDownException("Service is down");
		}
		
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		try{
			Account account=accountDAO.depositAmountToAccount(accountNo, amount);
		if(account==null)throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
		if(account.getStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
		return account.getAccountBalance();
		}catch(SQLException e){
			e.printStackTrace();
			throw new BankingServicesDownException("Banking Services are Down. Please try again later.", e);
		}
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		try{
			Account account=accountDAO.WithdrawAmountFromAccount(accountNo, amount,pinNumber);
			if(account==null)throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			if(account.getStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			if (account.getAccountBalance()<0)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			if (account.getPinNumber()==0) {
				throw new InvalidPinNumberException("The pin entered is invalid. Please enter a valid pin");	
		}
			return account.getAccountBalance();
		}catch(SQLException e){
		e.printStackTrace();
		throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
	}
		
	}


	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		try {
			Account account=accountDAO.findOne(accountNoFrom);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		try {
			Account account = accountDAO.findOne(accountNo);
			if(account==null) throw new AccountNotFoundException("Account Details Not Found");
			return account;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Service is down",e);
		}
		
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		try {
			return accountDAO.findAllAccounts();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Banking Services are Down. Please try again later.", e);
		}
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		try {
			List<Transaction> transactions = accountDAO.fetchAllTransactions(accountNo);
			if (transactions == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return transactions;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Banking Services are Down. Please try again later.", e);
		}
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		try{Account account =  accountDAO.fetchAccountStatus(accountNo);
		if (account == null) throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
		if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
		return account.getStatus();
	} catch (SQLException e) {
		e.printStackTrace();
		throw new BankingServicesDownException("Banking Services are Down. Please try again later.", e);
	}
	}

}
