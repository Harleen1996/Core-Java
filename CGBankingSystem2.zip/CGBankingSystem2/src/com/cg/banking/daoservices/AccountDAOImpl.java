package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.util.ConnectionProvider;

public class AccountDAOImpl implements AccountDAO {
	private Connection conn = ConnectionProvider.getDBConnection();

	@Override
	public Account save(Account account) throws SQLException {
		try{conn.setAutoCommit(false);
		PreparedStatement pstmt1 = conn.prepareStatement("insert into account(pinNumber,accountType,status,accountBalance,accountNo)values(pin_seq.nextval,?,?,?,account__seq.nextval)");
		pstmt1.setString(1, account.getAccountType());
		pstmt1.setString(2, "Active");
		pstmt1.setFloat(3, account.getAccountBalance());
		pstmt1.executeUpdate();
		
		PreparedStatement pstmt2 = conn.prepareStatement("select max(accountNo) from account");
		ResultSet rs=pstmt2.executeQuery();
		rs.next();
	
		long accountNumber=rs.getLong(1);
		
		PreparedStatement pstmt3=conn.prepareStatement("insert into transaction(accountNo,transactionId,amount,transactionType)values(?,transaction__id.nextval,?,?)");
		pstmt3.setLong(1, accountNumber);
		pstmt3.setFloat(2, account.getAccountBalance());
		pstmt3.setString(3, "Deposit");
		
	   conn.commit();
	  // account.setAccountNo(accountNumber);
		return account;
		}catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{conn.setAutoCommit(true);	
		}
	}

	@Override
	public Account findOne(long accountNo) throws SQLException {
	PreparedStatement pstm1=conn.prepareStatement("select * from account where accountNo="+accountNo);
	ResultSet findAccountDetailsRS=pstm1.executeQuery();
	if(findAccountDetailsRS.next())
	{
		long accountNo1=findAccountDetailsRS.getLong("accountNo");
		int pinNumber=findAccountDetailsRS.getInt("pinNumber");
		String accountType=findAccountDetailsRS.getString("accountType");
		String status=findAccountDetailsRS.getString("status");
		float accountBalance=findAccountDetailsRS.getFloat("accountBalance");
		Account account=new Account(pinNumber,accountType,status,accountBalance,accountNo1,null);
		
		PreparedStatement pstmt2=conn.prepareStatement("select * from transaction where accountNo="+accountNo);
		ResultSet findTransactionDetailsRs=pstmt2.executeQuery();
		findTransactionDetailsRs.next();
		int transactionId=findTransactionDetailsRs.getInt("transactionId");
		float amount=findTransactionDetailsRs.getFloat("amount");
		String transactionType=findTransactionDetailsRs.getString("transactionType");
		account.setTransaction(new Transaction(transactionId,amount,transactionType));
		return account;
	}
	return null;
	}
	
	@Override
	public Account depositAmountToAccount(long accountNo, float amount) throws SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("select accountBalance,status from Account where accountNo="+accountNo);
		ResultSet fetchAccountDetails=pstmt1.executeQuery();
		if(fetchAccountDetails.next()){
			String accountStatus= fetchAccountDetails.getString("status");
			if(!accountStatus.equalsIgnoreCase("Blocked")){
				Float accountBalance=fetchAccountDetails.getFloat("accountBalance");
				Float newAccountBalance=accountBalance+amount;
				
				PreparedStatement pstmt2=conn.prepareStatement("update account set accountBalance=? where accountNo="+accountNo);
				pstmt2.setFloat(1, newAccountBalance);
				pstmt2.executeUpdate();
				
		PreparedStatement pstmt3=conn.prepareStatement("insert into transaction(accountNo,transactionId,amount,transactionType)values(?,transaction__id.nextval,?,?)");
		pstmt3.setLong(1, accountNo);
		pstmt3.setFloat(2, amount);
		pstmt3.setString(3, "Deposit");
		pstmt3.executeUpdate();
		Account account=new Account(newAccountBalance,accountStatus,accountNo);
		return account;
		}
		return new Account(0F,accountStatus,accountNo);
		}
		else return null;
	}
	

	@Override
	public Account WithdrawAmountFromAccount(long accountNo, float amount,int pinNumber) throws SQLException,InsufficientAmountException {
			PreparedStatement pstmt1=conn.prepareStatement("select * from Account where accountNo="+accountNo);
			ResultSet fetchAccountDetails=pstmt1.executeQuery();
			if(fetchAccountDetails.next()){
				String accountStatus= fetchAccountDetails.getString("status");
				String accountType=fetchAccountDetails.getString("accountType");
				if(!accountStatus.equalsIgnoreCase("Blocked")){
					int pin=fetchAccountDetails.getInt("pinNumber");
					if(pin==pinNumber){
					Float accountBalance=fetchAccountDetails.getFloat("accountBalance");
					Float newAccountBalance=accountBalance-amount;
					if(newAccountBalance>1000){
					PreparedStatement pstmt2=conn.prepareStatement("update account set accountBalance=? where accountNo="+accountNo);
					pstmt2.setFloat(1, newAccountBalance);
					pstmt2.executeUpdate();
					
			PreparedStatement pstmt3=conn.prepareStatement("insert into transaction(accountNo,transactionId,amount,transactionType)values(?,transaction__id.nextval,?,?)");
			pstmt3.setLong(1, accountNo);
			pstmt3.setFloat(2, amount);
			pstmt3.setString(3, "Deposit");
			pstmt3.executeUpdate();
			Account account=new Account(pin,accountType,accountStatus,newAccountBalance,accountNo);
			return account;
			}
					else return new Account(pin,accountType,accountStatus,-1,accountNo);
					}
					else	return new Account(0,accountType, accountStatus, 0, accountNo);
				}
				return new Account(0F,accountStatus,accountNo);
			}
			else return null;
		}

	@Override
	public Account fetchAccountStatus(long accountNo) throws SQLException {
	PreparedStatement pstmt1=conn.prepareStatement("select status from account where accountNo="+accountNo);
	ResultSet fetchaccountDetails=pstmt1.executeQuery();
	if(fetchaccountDetails.next()){
		return new Account(accountNo,fetchaccountDetails.getString("status"));
	}
		return null;
	}

	@Override
	public List<Account> findAllAccounts() throws SQLException {
		List<Account>accounts=new ArrayList<>();
		PreparedStatement pstmt1=conn.prepareStatement("select * from account");
		ResultSet fetchAccountDetails=pstmt1.executeQuery();
		while(fetchAccountDetails.next()){
			int pinNumber=fetchAccountDetails.getInt("");
			String accountType=fetchAccountDetails.getString("");
			String status=fetchAccountDetails.getString("");
			float accountBalance=fetchAccountDetails.getFloat("");
			long accountNo=fetchAccountDetails.getLong("");
				Account account=new Account(pinNumber,accountType,status,accountBalance,accountNo,null);
		accounts.add(account);	
	}
		return accounts;
	}
	

	@Override
	public List<Transaction> fetchAllTransactions(long accountNo)
			throws SQLException {
		List<Transaction> transactions = new ArrayList<>();
		PreparedStatement pstmt1 = conn.prepareStatement("select * from transaction");
		ResultSet fetchAccountDetails = pstmt1.executeQuery();
		while(fetchAccountDetails.next())
		{
			int transactionId=fetchAccountDetails.getInt("transactionId");
			float amount=fetchAccountDetails.getFloat("amount");
			String transactionType=fetchAccountDetails.getString("transactionType");
			Transaction transaction=new Transaction(transactionId,amount,transactionType);
		transactions.add(transaction);
		}
		if (transactions.size()>0)	return transactions;
		return null;
}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,float transferAmount, int pinNumber)throws SQLException{
		WithdrawAmountFromAccount(accountNoFrom, transferAmount, pinNumber);
		this.depositAmountToAccount(accountNoTo, transferAmount);
		
		

		return false;
	}
}


