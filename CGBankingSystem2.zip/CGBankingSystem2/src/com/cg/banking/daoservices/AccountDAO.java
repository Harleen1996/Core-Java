package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface AccountDAO {
	Account save(Account account) throws SQLException;
	Account findOne(long accountNo)throws SQLException;
	Account depositAmountToAccount(long accountNo,float amount) throws SQLException;
	Account WithdrawAmountFromAccount(long accountNo,float amount,int pinNumber) throws SQLException, InsufficientAmountException;
	
	Account fetchAccountStatus(long accountNo) throws SQLException;
	List<Account> findAllAccounts() throws SQLException;
	List<Transaction> fetchAllTransactions(long accountNo) throws SQLException;
	boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)throws SQLException;
	
}