package com.cg.project.client;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.beans.Employee;

public class MainClass2 {
	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		Collections.sort(empList, (emp1,emp2)->emp1.getSalary()-emp2.getSalary());
		
		empList.stream()
		.distinct()
		.filter(e -> e.getName().startsWith("N"))
		.forEach(employee->System.out.println(employee));
		
		long count = empList.stream()
				.distinct()
				.count();
		System.out.println(count + " " + empList.size());
	}
}