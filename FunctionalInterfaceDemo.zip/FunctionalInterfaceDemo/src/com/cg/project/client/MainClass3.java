package com.cg.project.client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainClass3 {

	public static void main(String[] args) {
		method1();
	}
	
		private static void method1(){
		Pattern pattern=Pattern.compile("H[abc]");
		Matcher matcher=pattern.matcher("Hello World How Are You");
		while(matcher.find())
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
	}
		
		private static void method2(){
			Pattern pattern=Pattern.compile("\\s");
			Matcher matcher=pattern.matcher("Hello World How Are You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}		
		
		private static void method3(){
			Pattern pattern=Pattern.compile("\\d");
			Matcher matcher=pattern.matcher("Hello World5 How A8e You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}	
		
		private static void method4(){
			Pattern pattern=Pattern.compile("Hel?");
			Matcher matcher=pattern.matcher("Hello World5 How A8e You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}	
}

