package com.cg.project.lamdainterface;

public interface FunctionalInterface1 {
	void greetUser(String firstname,String lastname);
}
