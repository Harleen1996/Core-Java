package com.cg.poject.beans;

public class MainClass {

	public static void main(String[] args) {
	Address address=new Address("Pune", "Maharashtra", "india", 4012011);
	Customer customer=new Customer(101," Harleen", "Aggarwal", address);
	

/*	Address address2=customer.getAddress();
	 System.out.println(address2.getCity());*/
	 
	System.out.println(customer.getAddress().getCity());
	                                    

	/*customer.getAddress().setCountry("New Country");
	customer.getAddress().setCity("New City");
	customer.getAddress().setState("New State");*/
	
	customer.setAddress(new Address("Mumbai","Maharashtra", "india",147001));
	System.out.println(customer.getAddress().getCity());
	
	Customer customer2=new Customer(102," Harleen", "Aggarwal", new Address("Patiala","Punjab", "india",147001));
	System.out.println(customer.getAddress().getCity());
	}

}
