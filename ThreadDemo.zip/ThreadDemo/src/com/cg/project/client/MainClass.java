package com.cg.project.client;

import com.cg.project.threadwork.RunnableResource;

public class MainClass {

	public static void main(String[] args) {
		/*RunnableResource r1=new RunnableResource();
		Thread th1=new Thread(r1,"abc");
		Thread th2=new Thread(r1,"pqr");
		
		th1.start();
		th2.start();*/
		
		
		/*RunnableResource r1=new RunnableResource();
		Thread th1=new Thread(r1,"abc");
		Thread th2=new Thread(r1,"pqr");
		th1.start();
		th2.start();*/
		
		
		/*RunnableResource r1=new RunnableResource();
		Thread th1=new Thread(r1,"abc");
		th1.start();
		try {
			th1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Thread th2=new Thread(r1,"pqr");
		th2.start();
		System.out.println("main method end here");*/
		
		Runnable runnableResource = () ->{
			for(int i=1;i<10;i++)
				System.out.println("Tick "+i);
		};
					Thread th1=new Thread(runnableResource);
					th1.start();
	
	}

}
