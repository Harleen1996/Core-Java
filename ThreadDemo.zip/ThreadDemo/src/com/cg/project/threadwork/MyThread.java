package com.cg.project.threadwork;

public class MyThread extends Thread{

	public MyThread(String name) {
		super(name);
	}

	@Override                                                                 
	public void run() {
		int l=100;
	if(this.getName().equals("odd"))
		for(int i=1;i<=l;i++)
			if(i%2!=0)
				System.out.println(i+" is odd");
	if(this.getName().equals("even"))
		for(int i=1;i<=l;i++)
			if(i%2==0)
				System.out.println(i+" is even");
	}
}



	
