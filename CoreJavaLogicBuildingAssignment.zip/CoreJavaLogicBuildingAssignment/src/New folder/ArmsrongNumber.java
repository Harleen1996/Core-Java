
public class ArmsrongNumber {

	public static void main(String[] args) {
		double c=0;
		int r,temp,count=4;  
	    int n=8208;//It is the number to check armstrong  
	    temp=n;  
	    while(n>0)  
	    {  
	    r=n%10;  
	    n=n/10;  
	    c +=  Math.pow(r,count);  
	    }  
	    if(temp==c)  
	    System.out.println("armstrong number");   
	    else  
	        System.out.println("Not armstrong number");   
	   }  
	}  
