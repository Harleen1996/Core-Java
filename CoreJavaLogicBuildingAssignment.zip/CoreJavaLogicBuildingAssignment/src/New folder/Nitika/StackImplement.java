
public class StackImplement {
	private int size;
	private static int []stackList;
	private static int top;
	public StackImplement(int i) {
		size=i;
		stackList=new int[i];
		top=-1;
	}
	private void push(int number){
		stackList[++top]=number;
	}
	private int pop(){
		return stackList[top--];
	}
	private boolean isEmpty(){
		return top==-1;
	}
	private boolean isFull(){
		return top==size-1;
	}
	public static void main(String[] args) {
		StackImplement stack=new StackImplement(10);
		stack.push(5);
		stack.push(50);
		stack.push(12);
		stack.push(70);
		System.out.println("Stack elements:");
		for(int i=0;i<=top;i++)
			System.out.println(stackList[i]+" ");
		System.out.println("After pop opration:\n");
		while (!stack.isEmpty()) {
			int value = stack.pop();
			System.out.print(value);
			System.out.print(" ");
		}
		System.out.println("\nStack is empty now");
	}

}
