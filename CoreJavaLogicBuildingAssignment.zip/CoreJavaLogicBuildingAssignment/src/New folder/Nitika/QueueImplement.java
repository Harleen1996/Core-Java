
public class QueueImplement {
	private int size;
	private static int []queueList; 
	 private int front;  
	 private int rear;  
	  
	 public QueueImplement(int i) {
		 size=i;
			queueList=new int[i];
			front=-1;
			rear=0;
	}

	public void enqueue(int enqueueedElement) {  
	  if (front < size - 1) {  
	   front++;  
	   queueList[front] = enqueueedElement;  
	   System.out.println("Element " + enqueueedElement   + " is enqueueed to Queue !");  
	   display();  
	  } else {  
	   System.out.println("Overflow !");  
	  }  
	 }  
	  
	 public void dequeue() {  
	  if (front >= rear) {  
	   rear++;  
	   display();  
	  } else {  
	   System.out.println("Underflow !");  
	  }  
	 }  
	  
	 public void display() {  
	  if (front >= rear) {  
	   System.out.println("Elements in Queue : ");  
	   for (int i = rear; i <= front; i++) {  
	    System.out.println(queueList[i]);  
	   }  
	  }  
	 }  
	  
	 public static void main(String[] args) {  
	  QueueImplement queue = new QueueImplement(10);  
	  queue.dequeue();  
	  queue.enqueue(23);  
	  queue.enqueue(2);  
	  queue.enqueue(73);  
	  queue.enqueue(21);  
	  queue.dequeue();  
	  queue.dequeue();  
	  queue.dequeue();  
	  queue.dequeue();  
	 }  

}
