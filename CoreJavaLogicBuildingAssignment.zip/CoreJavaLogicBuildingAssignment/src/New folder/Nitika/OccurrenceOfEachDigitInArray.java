import java.util.Scanner;


public class OccurrenceOfEachDigitInArray {

	public static void main(String[] args) {
		int i,temp = 0;
		int [] numList = {2,1,1,1,6,5,6,1}; 
		int [] count = new int[100];
		for(i = 0; i < numList.length; i++){
			temp = numList[i];
			count[temp]++;
		}
		for(i=1; i < count.length; i++){
			if(count[i] > 0 && count[i] == 1)
				System.out.printf("%d occurs %d time\n",i, count[i]);
			else if(count[i] >=2){
				System.out.printf("%d occurs %d times\n",i, count[i]);
			}
		}
	}
}
