
public class PalindromeNumber {

	public static void main(String[] args) {
		int n =505, reverse = 0, remainder=0;
		int temp = n;    
		while(n>0){    
			remainder= n % 10;   
			reverse = (reverse*10)+ remainder;    
			n = n/10;
		}    
		if(temp==reverse )    
			System.out.println("It is a Palindrome number.");    
		else    
			System.out.println("Not a palindrome");    
	}  
}

