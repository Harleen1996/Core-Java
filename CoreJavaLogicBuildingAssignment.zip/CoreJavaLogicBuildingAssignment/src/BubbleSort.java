
public class BubbleSort {
	public static void main(String []str){
		int numArr[]={5,10,2,8,11,14,1,19,7,3};
		int n=numArr.length,tmp;
		for(int i=0;i<n-1;i++){
			for(int j=0;j<n-i-1;j++){	
				if(numArr[j]>numArr[j+1]){	
					tmp=numArr[j];
					numArr[j]=numArr[j+1];
					numArr[j+1]=tmp;
				}
			}
		}
		for(int i=0;i<n;i++){
			System.out.print(numArr[i]+"   ");
		}
	}
}