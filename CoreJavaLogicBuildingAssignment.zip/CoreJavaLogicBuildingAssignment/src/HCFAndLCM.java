
public class HCFAndLCM {

	public static void main(String[] args) {
		int number1=25, number2=50;
		int copy1=number1, copy2=number2,t,hcf,lcm;
		while(copy2 != 0){
			t = copy2;
			copy2 = copy1%copy2;
			copy1 = t;
		}
		hcf = copy1;
		lcm = (number1*number2)/hcf;
		System.out.println("HCF and LCM of "+number1+" and "+number2+" : "+hcf+" , "+lcm);
	}
}
