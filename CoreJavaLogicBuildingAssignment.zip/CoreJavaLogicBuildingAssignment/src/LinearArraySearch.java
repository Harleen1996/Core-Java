
public class LinearArraySearch {

	public static void main(String[] args) {
		int numArr[]={5,10,2,8,11,14,1,19,7};
		int search=8;
		for(int i=0;i<numArr.length;i++){
			if(numArr[i]==search)
			{
				System.out.println("Number "+search+" found at index "+i);
				break;
			}
			if(i==numArr.length-1)
				System.out.println("Number not found");
		}
	}
}
