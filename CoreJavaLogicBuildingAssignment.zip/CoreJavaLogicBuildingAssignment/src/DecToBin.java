
public class DecToBin {
	public static void main(String []str){
		int binNum[]=new int[100];
		int decimal=15,i= 0; 
		while (decimal > 0){ 
			binNum[i]=decimal%2; 
			decimal=decimal/2; 
			i++;
		}
		for(int j=i-1;j>=0;j--){
			System.out.print(binNum[j]);
		} 
	}
}