
public class Swap {

	public static void main(String []str){
		int x=9,y=1;
		System.out.println("Before swap: "+x+" "+y);
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println("After swap: "+x+" "+y);
	}
}
