
public class Palindrome {

	public static void main(String []str){
		int originalNo=121,n1=originalNo,r,rev=0;
		while(n1!=0){
			r=n1%10;
			rev=rev*10 +r;
			n1/=10;
		}
		if(rev==originalNo)
			System.out.println("Number "+originalNo+" is palindrome");
		else
			System.out.println("Number "+originalNo+" is not palindrome");
	}
}
