public class BinarySearch {
	int binarySearch(int numArray[],int search){ 
			int lowInd= 0,highInd=numArray.length; 
	        while (lowInd<= highInd) { 
	            int mid=lowInd+(highInd-lowInd)/2; 
	            if (numArray[mid] == search) 
	                return mid; 
	            if (numArray[mid] < search) 
	                lowInd=mid+1; 
	            else
	                highInd=mid-1; 
	        } 
	        return -1; 
	    } 
	public static void main(String[] args) {
		 	BinarySearch ob = new BinarySearch(); 
	        int numArray[] = {2, 3, 4, 10, 40}; 
	        int search = 10; 
	        int result = ob.binarySearch(numArray,search); 
	        if (result == -1) 
	            System.out.println("Element absent"); 
	        else
	            System.out.println("Element found at index " + result);
	}

}
